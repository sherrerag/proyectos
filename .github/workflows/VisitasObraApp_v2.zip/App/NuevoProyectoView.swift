// NuevoProyectoView.swift
import SwiftUI