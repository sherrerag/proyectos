// DetalleVisitaView.swift
import SwiftUI