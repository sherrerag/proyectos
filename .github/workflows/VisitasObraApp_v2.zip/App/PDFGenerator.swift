// PDFGenerator.swift
import Foundation