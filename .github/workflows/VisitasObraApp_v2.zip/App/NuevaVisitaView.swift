// NuevaVisitaView.swift
import SwiftUI