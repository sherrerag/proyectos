// ActivityView.swift
import SwiftUI