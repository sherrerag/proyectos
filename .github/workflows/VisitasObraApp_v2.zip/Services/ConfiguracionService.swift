// ConfiguracionService.swift
import Foundation